<?php

namespace Twig\Error;

class_exists('Twig_Error_Runtime');

if (\false) {
    class RuntimeError extends \Twig_Error_Runtime
    {
    }
}
