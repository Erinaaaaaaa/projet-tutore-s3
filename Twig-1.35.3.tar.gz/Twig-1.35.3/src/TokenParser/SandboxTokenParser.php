<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Sandbox');

if (\false) {
    class SandboxTokenParser extends \Twig_TokenParser_Sandbox
    {
    }
}
