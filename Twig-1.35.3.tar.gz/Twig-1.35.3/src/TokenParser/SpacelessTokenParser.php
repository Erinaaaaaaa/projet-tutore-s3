<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Spaceless');

if (\false) {
    class SpacelessTokenParser extends \Twig_TokenParser_Spaceless
    {
    }
}
