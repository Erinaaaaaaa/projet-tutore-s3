<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Use');

if (\false) {
    class UseTokenParser extends \Twig_TokenParser_Use
    {
    }
}
