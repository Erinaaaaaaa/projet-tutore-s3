<?php

namespace Twig;

class_exists('Twig_NodeTraverser');

if (\false) {
    class NodeTraverser extends \Twig_NodeTraverser
    {
    }
}
