<?php

namespace Twig\Node;

class_exists('Twig_Node_Spaceless');

if (\false) {
    class SpacelessNode extends \Twig_Node_Spaceless
    {
    }
}
