<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_Range');

if (\false) {
    class RangeBinary extends \Twig_Node_Expression_Binary_Range
    {
    }
}
