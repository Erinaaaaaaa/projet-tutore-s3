<?php

namespace Twig\Node;

class_exists('Twig_Node_CheckSecurity');

if (\false) {
    class CheckSecurityNode extends \Twig_Node_CheckSecurity
    {
    }
}
