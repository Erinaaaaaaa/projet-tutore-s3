<?php

namespace Twig\Extension;

class_exists('Twig_ExtensionInterface');

if (\false) {
    interface ExtensionInterface extends \Twig_ExtensionInterface
    {
    }
}
